# pixpert-templates
안녕하세요. 골든웨일스 입니다.
Pixpert 어플리케이션에서 사용하는 템플릿 파일을 관리하는 저장소 입니다.
템플릿 파일은 zip 형식으로 업로드 됩니다.
여기에 업로드된 파일은 자유롭게 다운로드 하실 수 있습니다.


템플릿 파일(zip) 디렉토리 구조는 다음과 같습니다.  
(Your Template Zip File)
- /src (source)
- Your Template File (.json)


WebSite : http://pixpert.goldenwhales.com#portfolio


Copyrights GoldenWhales Corp. All Rights Reserved
